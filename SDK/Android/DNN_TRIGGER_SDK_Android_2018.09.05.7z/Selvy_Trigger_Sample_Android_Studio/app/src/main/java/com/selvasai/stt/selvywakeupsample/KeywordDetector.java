package com.selvasai.stt.selvywakeupsample;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder.AudioSource;
import android.util.AndroidRuntimeException;
import android.util.Log;

import com.selvasai.stt.selvywakeup.WakeUpSolid;

import java.io.Serializable;


/**
 * Created by mckeum on 2016-08-11.
 * Get audio using AudioRecord and detect keyword using WakeUpSolid
 */

class KeywordDetector extends Thread {
    private final static String TAG = "TriggerDetector";
    private boolean stopped = false;

    private WakeUpSolid wakeupInstance;
    private Callback cb;

    private short[][] buffers = new short[256][160];
    private int ix = 0;

    interface Callback extends Serializable {
        void callback(String txt);
    }

    KeywordDetector(Context context, Callback callback) {
        cb = callback;

        // Get singleton instance of WakeUpSolid
	    try {
		    wakeupInstance = WakeUpSolid.I(context);
	    } catch (WakeUpSolid.CreateEngineErrorException e) {
		    e.printStackTrace();
		    throw new AndroidRuntimeException(e);
	    }
    }

    @Override
    public void run() {
        // Reset WakeUpSolid
        wakeupInstance.reset();

        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);
        AudioRecord recorder = null;
        try {
            int N = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (AudioRecord.ERROR_BAD_VALUE == N) {
                cb.callback("ERROR: Device does not supports 16kHz audio recording!");
                return;
            }

            recorder = new AudioRecord(AudioSource.MIC, 16000,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, N * 16);
            recorder.startRecording();

            cb.callback("검출중...");
	        int _f_count = 0;
            while (!stopped) {
                short[] buffer = buffers[ix % buffers.length];
                N = recorder.read(buffer, 0, buffer.length);
                if (N <= 0) continue;
                ix++;

                // WakeUpSolid word detection
                //int det = wakeupInstance.detect(buffer);
	            int _frame_info[] = new int[2];
	            int det = wakeupInstance.detect(buffer,_frame_info);
	            _f_count += (buffer.length/160);
	            Log.d("cuniverse",String.format(">> [%08d] det: %d : %d / %d",_f_count,det,_frame_info[0],_frame_info[1]));
                if (det <= 0)   // not detected
                    continue;

                // detected
                cb.callback("Detected at " + det + " frame! Trigger Started at " + (_frame_info[0] - _frame_info[1]) + " frame ");
            }

            recorder.stop();
            cb.callback("중지됨");
        } catch (Throwable x) {
            Log.w(TAG, "Error reading voice audio", x);
            cb.callback("Error!");
        } finally {
            Log.d(TAG, "finally");
            if (recorder != null) {
                recorder.release();
            }
        }
    }

    void close() {
        Log.d(TAG, "close()");
        stopped = true;
    }
}

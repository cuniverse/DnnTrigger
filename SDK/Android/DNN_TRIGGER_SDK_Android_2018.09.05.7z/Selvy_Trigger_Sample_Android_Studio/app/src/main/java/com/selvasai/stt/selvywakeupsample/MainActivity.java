package com.selvasai.stt.selvywakeupsample;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.selvasai.stt.selvywakeup.WakeUpSolid;

public class MainActivity extends AppCompatActivity {
    private final static String TAG = "WakeUp Sample MainActivity";

    private KeywordDetector detectingThread;

    TextView tvSampleText;

    KeywordDetector.Callback kdcb = new KeywordDetector.Callback() {
        @Override
        public void callback(final String txt) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    String new_text = txt + "\n" + tvSampleText.getText().toString();
                    tvSampleText.setText(new_text);
                }
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        tvSampleText = (TextView) findViewById(R.id.tv_log);

        // 미리 초기화 작업을 수행 (버튼 탭 시 반응성 향상)
	    try {
		    WakeUpSolid.I(this);
	    } catch (WakeUpSolid.CreateEngineErrorException e) {
		    e.printStackTrace();
		    Toast.makeText(this,"Engine Create Error Check Android LOG and Error CODE!!",Toast.LENGTH_LONG).show();
		    finish();

	    }

	    FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start detection
                if (detectingThread != null) return;
                try {
	                detectingThread = new KeywordDetector(getApplicationContext(), kdcb);
	                detectingThread.start();

	                Snackbar.make(findViewById(R.id.content_main), "Detection started!", Snackbar.LENGTH_LONG)
			                .setAction("Action", null).show();
                }catch (Exception e)
                {
	                Toast.makeText(MainActivity.this,"Engine Create Error Check Android LOG and Error CODE!!",Toast.LENGTH_LONG).show();
	                finish();
                }
            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();

        // Stop detection
        if (null == detectingThread) return;
        detectingThread.close();
        try {
            detectingThread.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
        detectingThread = null;
    }
}
